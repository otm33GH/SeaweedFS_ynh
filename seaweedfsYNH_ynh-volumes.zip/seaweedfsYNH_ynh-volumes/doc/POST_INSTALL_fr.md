:wrench: L'URL de l'__interface admin__ est __<https://__DOMAIN____PATH__admin>__. Seuls les utilisateurs du groupe __admins__ peuvent y accéder.  
:key: L'adresse de l'API est <https://__DOMAIN____PATH__>.  
