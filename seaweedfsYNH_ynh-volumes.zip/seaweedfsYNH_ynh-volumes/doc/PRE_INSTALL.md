It is the __API__ that is installed at the __root of the site__.  
The __admin interface__ is accessible at <https://domain.tld/admin> and is available only to __users in the admins group__.
