Existing workers will be removed.  
Only the default worker will be created.  
