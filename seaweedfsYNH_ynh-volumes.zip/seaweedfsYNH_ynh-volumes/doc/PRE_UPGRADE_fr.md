Les workers existant seront supprimés.  
Seul le worker par défaut sera recréé.  
