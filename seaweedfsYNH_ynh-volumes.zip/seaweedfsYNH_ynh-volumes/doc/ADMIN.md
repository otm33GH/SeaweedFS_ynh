The admin URL is <https://__DOMAIN____PATH__admin>. Only admin users are allowed.  
The API URL is <https://__DOMAIN____PATH__>.  

The data directory for the default volume server is located at `/home/yunohost.app/seaweedfs/datadir`.  
Additional data directories can be added via config panel.
