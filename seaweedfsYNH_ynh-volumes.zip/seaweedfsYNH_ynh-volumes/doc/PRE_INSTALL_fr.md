C'est l'__API__ qui est installée à la __racine du site__.  
L'__interface admin__ est accessible à l'adresse <https://domain.tld/admin> et n'est accessible qu'aux __utilisateurs du groupe admins__.
