:wrench: The __admin URL__ is __<https://__DOMAIN____PATH__admin>__. Only __admin users__ are allowed.  
:key: The API URL is <https://__DOMAIN____PATH__>.  

