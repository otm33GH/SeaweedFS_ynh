L'URL de l'interface admin est <https://__DOMAIN____PATH__admin>. Seuls les utilisateurs du groupe __admins__ peuvent y accéder.  
L'adresse de l'API est <https://__DOMAIN____PATH__>.  

Le répertoire de données du premier pod volume est situé dans `/home/yunohost.app/seaweedfs/datadir`.  
D'autres répertoires peuvent être ajoutés via le panneau de configuration.  
